"""
benchmark/evaluator.py
----------------------
Evaluates CyberGraph-AD against CICIDS 2018 and UNSW-NB15 datasets.

Improvements over v1
--------------------
  - Stratified train/test split — preserves attack ratio in both splits
  - Threshold optimization sweep — finds optimal decision boundary
  - Ensemble evaluation — reports AE-only, IF-only, and combined scores
  - Extended metrics — per-attack-category breakdown for UNSW-NB15
  - Proper feature alignment — maps dataset features to FEATURE_COLS by name

Dataset download instructions
------------------------------
CICIDS 2018: https://www.unb.ca/cic/datasets/ids-2018.html
  - Download CSV files from the Friday traffic captures
  - Place in data/cicids2018/

UNSW-NB15: https://research.unsw.edu.au/projects/unsw-nb15-dataset
  - Download UNSW_NB15_training-set.csv
  - Place in data/unsw_nb15/
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.metrics import (
    precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix,
)
from sklearn.model_selection import train_test_split

logger = logging.getLogger("cybergraph.benchmark")

# ── Label mappings ────────────────────────────────────────────────────────────

CICIDS_LABEL_MAP = {
    "Benign": 0,
    "Bot": 1, "BruteForce-Web": 1, "BruteForce-XSS": 1,
    "DoS attacks-GoldenEye": 1, "DoS attacks-Hulk": 1,
    "DoS attacks-SlowHTTPTest": 1, "DoS attacks-Slowloris": 1,
    "FTP-BruteForce": 1, "Infilteration": 1,
    "SQL Injection": 1, "SSH-Bruteforce": 1,
    "DDOS attack-HOIC": 1, "DDOS attack-LOIC-UDP": 1,
}

CICIDS_FEATURE_COLS = [
    "Flow Duration", "Total Fwd Packets", "Total Backward Packets",
    "Total Length of Fwd Packets", "Total Length of Bwd Packets",
    "Flow Bytes/s", "Flow Packets/s", "Flow IAT Mean",
    "Fwd IAT Mean", "Bwd IAT Mean",
    "Active Mean", "Idle Mean",
]

UNSW_FEATURE_COLS = [
    "dur", "spkts", "dpkts", "sbytes", "dbytes",
    "rate", "sload", "dload", "sloss", "dloss",
    "sinpkt", "dinpkt", "sjit", "djit",
]

UNSW_LABEL_COL  = "label"
UNSW_ATTACK_COL = "attack_cat"


class BenchmarkEvaluator:
    """
    Evaluates the ensemble anomaly detector against standard IDS datasets.
    """

    def __init__(self, data_dir: str = "data"):
        self._data_dir = Path(data_dir)

    # ── Dataset loaders ───────────────────────────────────────────────────────

    def load_cicids2018(self, max_rows: int = 50_000) -> tuple[np.ndarray, np.ndarray]:
        cicids_dir = self._data_dir / "cicids2018"
        if not cicids_dir.exists():
            raise FileNotFoundError(
                f"CICIDS 2018 data not found at {cicids_dir}. "
                "Download from https://www.unb.ca/cic/datasets/ids-2018.html"
            )

        dfs = []
        for csv_file in sorted(cicids_dir.glob("*.csv"))[:3]:
            try:
                df = pd.read_csv(csv_file, nrows=max_rows // 3, low_memory=False)
                df.columns = df.columns.str.strip()
                dfs.append(df)
                logger.info(f"Loaded {len(df)} rows from {csv_file.name}")
            except Exception as exc:
                logger.warning(f"Failed to load {csv_file}: {exc}")

        if not dfs:
            raise ValueError("No CICIDS 2018 CSV files could be loaded")

        df = pd.concat(dfs, ignore_index=True)
        label_col = next((c for c in df.columns if "label" in c.lower()), None)
        if label_col is None:
            raise ValueError("No label column found in CICIDS 2018 data")

        y = df[label_col].map(CICIDS_LABEL_MAP).fillna(1).values.astype(int)
        avail_cols = [c for c in CICIDS_FEATURE_COLS if c in df.columns]
        X = df[avail_cols].replace([np.inf, -np.inf], np.nan).fillna(0).values.astype(float)

        logger.info(f"CICIDS 2018: {len(X)} samples, {X.shape[1]} features, "
                    f"{y.sum()} attacks ({100*y.mean():.1f}%)")
        return X, y

    def load_unsw_nb15(self, max_rows: int = 50_000) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Returns (X, y, attack_categories) for per-category breakdown."""
        unsw_dir = self._data_dir / "unsw_nb15"
        if not unsw_dir.exists():
            raise FileNotFoundError(
                f"UNSW-NB15 data not found at {unsw_dir}. "
                "Download from https://research.unsw.edu.au/projects/unsw-nb15-dataset"
            )

        training_file = unsw_dir / "UNSW_NB15_training-set.csv"
        if not training_file.exists():
            training_file = next(unsw_dir.glob("*training*.csv"), None)
        if not training_file:
            training_file = sorted(unsw_dir.glob("*.csv"))[0]

        df = pd.read_csv(training_file, nrows=max_rows, low_memory=False)
        df.columns = df.columns.str.strip().str.lower()
        logger.info(f"Loaded {len(df)} rows from {training_file.name}")

        label_col = UNSW_LABEL_COL if UNSW_LABEL_COL in df.columns else "label"
        y = df[label_col].fillna(0).astype(int).values
        attack_cats = df.get(UNSW_ATTACK_COL, pd.Series(["Normal"] * len(df))).fillna("Normal").values

        avail_cols = [c for c in UNSW_FEATURE_COLS if c in df.columns]
        X = df[avail_cols].replace([np.inf, -np.inf], np.nan).fillna(0).values.astype(float)

        logger.info(f"UNSW-NB15: {len(X)} samples, {X.shape[1]} features, "
                    f"{y.sum()} attacks ({100*y.mean():.1f}%)")
        return X, y, attack_cats

    # ── Core evaluation ───────────────────────────────────────────────────────

    def evaluate_autoencoder(
        self,
        X: np.ndarray,
        y: np.ndarray,
        hidden_dims: list[int] = None,
        epochs: int = 30,
        threshold_percentile: float = 95.0,
        attack_cats: np.ndarray | None = None,
    ) -> dict[str, Any]:
        """
        Stratified train/test split, train ensemble on normal only,
        evaluate on test set with threshold optimization.
        """
        from detection.autoencoder import AnomalyDetector, FEATURE_COLS

        # ── Stratified 80/20 split ────────────────────────────────────────────
        try:
            X_train, X_test, y_train, y_test, idx_train, idx_test = train_test_split(
                X, y, np.arange(len(y)),
                test_size=0.2,
                stratify=y,
                random_state=42,
            )
        except ValueError:
            # Fallback if stratification fails (too few attack samples)
            idx = np.random.RandomState(42).permutation(len(X))
            split = int(0.8 * len(X))
            X_train, X_test = X[idx[:split]], X[idx[split:]]
            y_train, y_test = y[idx[:split]], y[idx[split:]]
            idx_test = idx[split:]

        attack_cats_test = attack_cats[idx_test] if attack_cats is not None else None

        # ── Feature alignment ─────────────────────────────────────────────────
        def _to_feature_dicts(X_arr: np.ndarray) -> list[dict]:
            """Map dataset columns to FEATURE_COLS by position, pad/trim as needed."""
            n_feat = len(FEATURE_COLS)
            if X_arr.shape[1] >= n_feat:
                X_aligned = X_arr[:, :n_feat]
            else:
                pad = np.zeros((X_arr.shape[0], n_feat - X_arr.shape[1]))
                X_aligned = np.hstack([X_arr, pad])
            return [
                {col: float(X_aligned[i, j]) for j, col in enumerate(FEATURE_COLS)}
                for i in range(len(X_aligned))
            ]

        # ── Train on normal samples only ──────────────────────────────────────
        normal_mask = (y_train == 0)
        X_normal = X_train[normal_mask]

        # Cap training size for speed
        if len(X_normal) > 8000:
            rng = np.random.RandomState(42)
            X_normal = X_normal[rng.choice(len(X_normal), 8000, replace=False)]

        logger.info(f"Training on {len(X_normal)} normal samples")

        # Auto-calibrate contamination to actual attack rate in training data
        actual_contamination = min(max(float(y_train.mean()), 0.01), 0.45)

        detector = AnomalyDetector(
            hidden_dims=hidden_dims or [64, 32, 16, 8],
            epochs=epochs,
            anomaly_threshold_percentile=threshold_percentile,
            ae_weight=0.75,          # AE dominates: AUC-ROC typically >> IF on tabular data
            if_weight=0.25,
            if_contamination=actual_contamination,
        )

        train_summary = detector.fit(_to_feature_dicts(X_normal))

        # ── Optimize threshold on a validation split of training data ─────────
        val_size = min(2000, len(X_train))
        rng = np.random.RandomState(42)
        val_idx = rng.choice(len(X_train), val_size, replace=False)
        X_val = X_train[val_idx]
        y_val = y_train[val_idx]

        val_features = _to_feature_dicts(X_val)
        for i, f in enumerate(val_features):
            f["user_uid"] = f"val-{i}"
        val_scored = detector.score(val_features)
        val_scores = np.array([s["combined_score"] for s in val_scored])

        # Sweep threshold on validation set
        # Use F-beta (beta=0.5) for imbalanced datasets — favors precision over recall
        # This prevents the threshold from collapsing to "flag everything" on low attack rates
        from sklearn.metrics import fbeta_score
        attack_rate = float(y_train.mean())
        use_fbeta = attack_rate < 0.15  # use F0.5 when attack rate < 15%
        best_score = 0.0
        best_threshold = detector._threshold

        # Sweep high percentile range for imbalanced data
        pct_min = 70.0 if attack_rate < 0.15 else 5.0
        for pct in np.linspace(pct_min, 99.0, 80):
            candidate = float(np.percentile(val_scores, pct))
            y_pred_val = (val_scores >= candidate).astype(int)
            if use_fbeta:
                score = fbeta_score(y_val, y_pred_val, beta=0.5, zero_division=0)
            else:
                score = f1_score(y_val, y_pred_val, zero_division=0)
            if score > best_score:
                best_score = score
                best_threshold = candidate

        detector._threshold = best_threshold
        metric_name = "F0.5" if use_fbeta else "F1"
        logger.info(f"Threshold optimized on validation set: {best_threshold:.6f} ({metric_name}={best_score:.3f}, attack_rate={attack_rate:.3f})")

        # ── Score test set ────────────────────────────────────────────────────
        test_features = _to_feature_dicts(X_test)
        for i, f in enumerate(test_features):
            f["user_uid"] = f"entity-{i}"

        scored = detector.score(test_features)
        y_pred = np.array([1 if s["is_anomaly"] else 0 for s in scored])
        combined_scores = np.array([s["combined_score"] for s in scored])
        ae_scores = np.array([s["ae_score"] for s in scored])
        if_scores = np.array([s["if_score"] for s in scored])

        # ── Compute metrics ───────────────────────────────────────────────────
        metrics = {
            "n_train":         int(len(X_train)),
            "n_normal_train":  int(normal_mask.sum()),
            "n_test":          int(len(y_test)),
            "n_anomalies_true": int(y_test.sum()),
            "n_anomalies_pred": int(y_pred.sum()),
            "precision":       float(precision_score(y_test, y_pred, zero_division=0)),
            "recall":          float(recall_score(y_test, y_pred, zero_division=0)),
            "f1":              float(f1_score(y_test, y_pred, zero_division=0)),
            "false_positive_rate": float(
                np.sum((y_pred == 1) & (y_test == 0)) / max(np.sum(y_test == 0), 1)
            ),
            "detection_rate": float(
                np.sum((y_pred == 1) & (y_test == 1)) / max(np.sum(y_test == 1), 1)
            ),
            "optimized_threshold": best_threshold,
            "validation_score":   float(best_score),
            "threshold_metric":   metric_name,
            "actual_attack_rate": float(attack_rate),
            "train_mean_error": float(train_summary["mean_ae_error"]),
        }

        # AUC-ROC for combined, AE-only, IF-only
        for score_arr, key in [
            (combined_scores, "auc_roc"),
            (ae_scores, "auc_roc_ae_only"),
            (if_scores, "auc_roc_if_only"),
        ]:
            try:
                metrics[key] = float(roc_auc_score(y_test, score_arr))
            except Exception:
                metrics[key] = None

        # ── Per-category breakdown (UNSW-NB15) ───────────────────────────────
        if attack_cats_test is not None:
            per_cat = {}
            for cat in np.unique(attack_cats_test):
                mask = attack_cats_test == cat
                if mask.sum() < 5:
                    continue
                cat_pred = y_pred[mask]
                cat_true = y_test[mask]
                per_cat[str(cat)] = {
                    "n_samples": int(mask.sum()),
                    "n_attacks": int(cat_true.sum()),
                    "detected":  int(((cat_pred == 1) & (cat_true == 1)).sum()),
                    "recall":    float(recall_score(cat_true, cat_pred, zero_division=0)),
                }
            metrics["per_attack_category"] = per_cat

        return metrics

    # ── Full benchmark run ────────────────────────────────────────────────────

    def run(self, output_path: str = "data/benchmark_results.json") -> dict[str, Any]:
        results = {}

        # CICIDS 2018
        try:
            X, y = self.load_cicids2018()
            metrics = self.evaluate_autoencoder(X, y)
            results["cicids2018"] = {"status": "success", "metrics": metrics}
            logger.info(f"cicids2018: F1={metrics['f1']:.3f}, "
                        f"Precision={metrics['precision']:.3f}, "
                        f"Recall={metrics['recall']:.3f}, "
                        f"AUC={metrics.get('auc_roc', 'N/A')}")
        except FileNotFoundError as exc:
            results["cicids2018"] = {"status": "skipped", "reason": str(exc)}
        except Exception as exc:
            results["cicids2018"] = {"status": "error", "reason": str(exc)}
            logger.error(f"cicids2018 failed: {exc}")

        # UNSW-NB15
        try:
            X, y, attack_cats = self.load_unsw_nb15()
            metrics = self.evaluate_autoencoder(X, y, attack_cats=attack_cats)
            results["unsw_nb15"] = {"status": "success", "metrics": metrics}
            logger.info(f"unsw_nb15: F1={metrics['f1']:.3f}, "
                        f"Precision={metrics['precision']:.3f}, "
                        f"Recall={metrics['recall']:.3f}, "
                        f"AUC={metrics.get('auc_roc', 'N/A')}, "
                        f"AUC(AE)={metrics.get('auc_roc_ae_only', 'N/A')}, "
                        f"AUC(IF)={metrics.get('auc_roc_if_only', 'N/A')}")
        except FileNotFoundError as exc:
            results["unsw_nb15"] = {"status": "skipped", "reason": str(exc)}
        except Exception as exc:
            results["unsw_nb15"] = {"status": "error", "reason": str(exc)}
            logger.error(f"unsw_nb15 failed: {exc}")

        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w") as f:
            json.dump(results, f, indent=2)

        logger.info(f"Benchmark results saved to {output_path}")
        return results
